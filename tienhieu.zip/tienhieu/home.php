<?php get_header(); ?>
  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/hero-bg.jpg" alt="" data-aos="fade-in">

      <div class="container">
        <div class="row">
          <div class="col-xl-4">
            <h1 data-aos="fade-up">Focus On What Matters</h1>
            <blockquote data-aos="fade-up" data-aos-delay="100">
              <p>VIVAIO is a leading solutions company based in Vietnam, specializing in the provision of open structured cabling systems. Our mission is to deliver high-quality, reliable, and innovative solutions that meet the diverse needs of our clients.</p>
            </blockquote>
            <div class="d-flex" data-aos="fade-up" data-aos-delay="200">
              <a href="<?php echo home_url(); ?>/contact" class="btn-get-started">Get Started</a>
              <a href="<?php echo home_url();?>/solutions/" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Watch Video</span></a>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Hero Section -->

    <!-- Why Us Section -->
    <section id="why-us" class="why-us section">

      <div class="container">

        <div class="row g-0">

          <div class="col-xl-5 img-bg" data-aos="fade-up" data-aos-delay="100">
            <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/why-us-bg.jpg" alt="">
          </div>

          <div class="col-xl-7 slides position-relative" data-aos="fade-up" data-aos-delay="200">

            <div class="swiper init-swiper">

              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Enhance Your Green Spaces with VIVAIO</h3>
                    <h4 class="mb-3">Dedicated to delivering exceptional quality and sustainable solutions.</h4>
                    <p>At VIVAIO, we believe in enhancing your outdoor environments with top-tier horticultural products. Our commitment to sustainability and quality ensures that every plant, tool, and accessory we offer helps you create vibrant and eco-friendly spaces.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Tailored Solutions for Every Landscape</h3>
                    <h4 class="mb-3">Customized products designed to meet your unique needs.</h4>
                    <p>From bespoke garden designs to robust landscaping tools, VIVAIO provides everything you need to bring your vision to life. Our products are crafted to suit various climatic conditions, ensuring longevity and thriving greenery.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Pioneering Innovation in Horticulture</h3>
                    <h4 class="mb-3">Stay ahead with our cutting-edge gardening technology.</h4>
                    <p>Embrace the future of gardening with VIVAIO's innovative solutions. Our advanced tools and technologies are designed to simplify your gardening efforts while maximizing growth and sustainability.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Committed to Customer Satisfaction</h3>
                    <h4 class="mb-3">Your gardening success is our top priority.</h4>
                    <p>At VIVAIO, we go beyond just selling products—we provide a partnership. Our expert team is dedicated to supporting you at every step of your gardening journey, ensuring a fruitful and enjoyable experience.</p>
                  </div>
                </div><!-- End slide item -->

              </div>
              <div class="swiper-pagination"></div>
            </div>

            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
          </div>

        </div>

      </div>

    </section><!-- /Why Us Section -->

    <!-- Solutions Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Our Solutions</h2>
        <p>Explore our diverse range of horticultural products designed to meet your unique landscaping needs.</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <!-- Service Item 1 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="bi bi-tree" style="color: #f57813;"></i></div>
            <div>
              <h4 class="title">Sustainable Plant Solutions</h4>
              <p class="description">Our wide selection of plants and trees are cultivated with sustainability in mind, ensuring healthy growth and eco-friendliness for every landscape.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div>
          <!-- End Service Item 1 -->

          <!-- Service Item 2 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="bi bi-tools" style="color: #15a04a;"></i></div>
            <div>
              <h4 class="title">Innovative Garden Tools</h4>
              <p class="description">Discover our range of cutting-edge garden tools, designed to simplify maintenance and enhance the beauty of your green spaces.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 2 -->

          <!-- Service Item 3 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="icon flex-shrink-0"><i class="bi bi-droplet" style="color: #d90769;"></i></div>
            <div>
              <h4 class="title">Water Management Systems</h4>
              <p class="description">Efficient irrigation solutions that conserve water and ensure optimal hydration for your plants and landscapes.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 3 -->

          <!-- Service Item 4 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="icon flex-shrink-0"><i class="bi bi-flower3" style="color: #15bfbc;"></i></div>
            <div>
              <h4 class="title">Premium Soil and Fertilizers</h4>
              <p class="description">High-quality soils and fertilizers that provide the essential nutrients your plants need for robust growth and vibrant blooms.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 4-->

          <!-- Service Item 5 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="500">
            <div class="icon flex-shrink-0"><i class="bi bi-globe" style="color: #f5cf13;"></i></div>
            <div>
              <h4 class="title">Global Reach and Support</h4>
              <p class="description">Our products and services are available worldwide, backed by comprehensive customer support to assist you at every step.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 5 -->

          <!-- Service Item 6 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="600">
            <div class="icon flex-shrink-0"><i class="bi bi-people" style="color: #1335f5;"></i></div>
            <div>
              <h4 class="title">Consultation and Design Services</h4>
              <p class="description">Leverage our expertise with personalized consultations and landscape design services tailored to your specific needs and vision.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 6 -->

        </div>

      </div>

    </section><!-- /Solutions Section -->

    <!-- Call To Action Section -->
    <section id="call-to-action" class="call-to-action section dark-background">

      <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cta-bg.jpg" alt="">

      <div class="container">
        <div class="row justify-content-center" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-xl-10">
            <div class="text-center">
              <h3>Ready to Elevate Your Business?</h3>
              <p>Join us in transforming your business with innovative solutions and dedicated support. Together, we can drive success and growth, tailored specifically to your needs.</p>
              <a class="cta-btn" href="<?php echo home_url(); ?>/contact">Get Started Now</a>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Call To Action Section -->

    <!-- Features Section -->
    <section id="features" class="features section">

      <div class="container">
        <div class="row">
          <div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
            <h3 class="mb-0">Advanced Features for</h3>
            <h3>Your Business Growth</h3>

            <div class="row gy-4">

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-eye" style="color: #ff8b2c;"></i>
                  <span>Streamlined Shopping Experience</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-graph-up" style="color: #ff5828;"></i>
                  <span>Data-Driven Insights</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-puzzle" style="color: #5578ff;"></i>
                  <span>Comprehensive Integration Tools</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-lightbulb" style="color: #e80368;"></i>
                  <span>Innovative Solutions & Ideas</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-award" style="color: #ffa76e;"></i>
                  <span>Award-Winning Support</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-shield-check" style="color: #11dbcf;"></i>
                  <span>Security You Can Trust</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-broadcast" style="color: #4233ff;"></i>
                  <span>Live Streaming Capabilities</span>
                </div>
              </div><!-- End Icon List Item-->

              <div class="col-md-6">
                <div class="icon-list d-flex">
                  <i class="bi bi-cpu" style="color: #29cc61;"></i>
                  <span>High-Performance Computing</span>
                </div>
              </div><!-- End Icon List Item-->
            </div>
          </div>
          <div class="col-lg-5 position-relative" data-aos="zoom-out" data-aos-delay="200">
            <div class="phone-wrap">
              <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/iphone.png" alt="Image" class="img-fluid">
            </div>
          </div>
        </div>

      </div>

      <div class="details">
        <div class="container">
          <div class="row">
            <div class="col-md-6" data-aos="fade-up" data-aos-delay="300">
              <h4>Explore Our Solutions</h4>
              <p>Discover how our features can help drive your business forward, enhancing productivity and ensuring success in an ever-competitive market.</p>
              <a href="<?php echo home_url(); ?>/about" class="btn-get-started">Get Started</a>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Features Section -->

  </main>
<?php get_footer(); ?>
<script>  var swiper = new Swiper(".swiper.init-swiper", {
    cssMode: true,
    loop: true,
    speed: 800,
    autoplay:{
      delay: 5000,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
      clickable: true
    },
    mousewheel: true,
    keyboard: true,
    breakpoints: {
      768: {
        slidesPerView: 1,
        spaceBetween: 40
            },
      1200: {
        slidesPerView: 1,
        spaceBetween: 1
            }
      }
  });
  </script>