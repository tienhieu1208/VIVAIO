<?php if (is_active_sidebar('shop-sidebar')) : ?>
    <aside id="secondary" class="widget-area shop-sidebar">
        <?php dynamic_sidebar('shop-sidebar'); ?>
    </aside>
<?php endif; ?>
