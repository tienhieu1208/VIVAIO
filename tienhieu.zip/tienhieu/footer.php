<footer id="footer" class="footer light-background">

<div class="footer-top">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-5 col-md-12 footer-about">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="logo d-flex align-items-center">
          <span class="sitename">
          <?php
            if ( function_exists( 'the_custom_logo' ) ) {
	            the_custom_logo();
            }
          ?>
          </span>
        </a>
        <p></p>
        <p>Nurturing your green spaces with passion and expertise. At VIVAIO, we believe in creating vibrant, sustainable environments that flourish year-round. Trust us to bring your landscapes to life with innovative solutions and dedicated support.</p>
        <div class="social-links d-flex mt-4">
          <a href="#"><i class="bi bi-twitter-x"></i></a>
          <a target="_blank" href="https://www.facebook.com/profile.php?id=61560080015903"><i class="bi bi-facebook"></i></a>
          <a href="#"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><a href="<?php echo home_url();?>">Home</a></li>
          <li><a href="<?php echo home_url();?>/about/">About us</a></li>
          <li><a href="<?php echo home_url();?>/solutions/">Solutions</a></li>
          <li><a href="#">Terms of service</a></li>
          <li><a href="#">Privacy policy</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Our Solutions</h4>
        <ul>
          <li><a href="<?php echo home_url();?>/product-category/control-cable-solutions/">Control Cable Solutions</a></li>
          <li><a href="<?php echo home_url();?>/product-category/elv-box-solutions/">ELV Box Solutions</a></li>
          <li><a href="<?php echo home_url();?>/product-category/fiber-optic-solutions/">Fiber Optic Solutions</a></li>
          <li><a href="<?php echo home_url();?>/product-category/lan-cable-solutions/">Lan Cable Solutions</a></li>
          <li><a href="<?php echo home_url();?>/product-category/micro-data-center-solutions">Micro Data Center Solutions</a></li>
          <li><a href="<?php echo home_url();?>/product-category/rack-cabinet-solutions">Rack-Cabinet Solutions</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
        <h4>Contact Us</h4>
        <p>2529 Story Road</p>
        <p>California, CA 95122</p>
        <p>United States</p>
        <p class="mt-4"><strong>Email:</strong> <span>info@vivaio-electric.com</span></p>
      </div>

    </div>
  </div>
</div>

<div class="container copyright text-center">
  <p><span>Copyright © 2024 VIVAIO. All rights reserved</span></p>

  <!-----------------------------------
  <div class="credits">
    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
  </div>
  ----------------------------------->
</div>

</footer>

<!-- Scroll Top -->
<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Preloader -->
<div id="preloader"></div>

</body>

</html>
<?php wp_footer(); ?>