<?php

// Dedicate directory root const
define('VIVAIO_THEME_DIR',get_template_directory());
define('VIVAIO_THEME_URI',get_template_directory_uri());
define('VIVAIO_THEME_ASSETS',VIVAIO_THEME_URI.'/assets');
define('VIVAIO_THEME_CSS',VIVAIO_THEME_URI.'/css');
define('VIVAIO_THEME_FAVICON',VIVAIO_THEME_URI.'/favicon');
define('VIVAIO_THEME_FORMS',VIVAIO_THEME_URI.'/forms');
define('VIVAIO_THEME_JS',VIVAIO_THEME_URI.'/js');
define('VIVAIO_THEME_LANG',VIVAIO_THEME_DIR.'/lang');
define('VIVAIO_THEME_TEMPLATES',VIVAIO_THEME_URI.'/templates');
define('VIVAIO_THEME_MDB5',VIVAIO_THEME_URI.'/mdb5');

// Dedicate CSS by wp_enqueue_style()
function dedicate_wp_enqueue() {
    // Favicons
    wp_enqueue_style('vivaio_theme_stylesheet_favicons_1',VIVAIO_THEME_ASSETS.'/img/favicon.png',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_favicons_2',VIVAIO_THEME_ASSETS.'/img/apple-touch-icon.png',array(),'1.0','all');
    // Fonts
    wp_enqueue_style('vivaio_theme_stylesheet_fonts_1','https://fonts.googleapis.com',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_fonts_2','https://fonts.gstatic.com',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_fonts_3','https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap',array(),'1.0','all');
    // Google Fonts Roboto
    wp_enqueue_style('vivaio_theme_stylesheet_google_fonts_roboto_1','https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap',array(),'1.0','all');
    // Main CSS File
    wp_enqueue_style('vivaio_theme_stylesheet_css_main',VIVAIO_THEME_ASSETS.'/css/main.css',array(),'1.0','all');
    // Vendor CSS File
    wp_enqueue_style('vivaio_theme_stylesheet_vendor_1',VIVAIO_THEME_ASSETS.'/vendor/bootstrap/css/bootstrap.min.css',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_vendor_2',VIVAIO_THEME_ASSETS.'/vendor/bootstrap-icons/bootstrap-icons.css',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_vendor_3',VIVAIO_THEME_ASSETS.'/vendor/aos/aos.css',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_vendor_4',VIVAIO_THEME_ASSETS.'/vendor/glightbox/css/glightbox.min.css',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_vendor_5',VIVAIO_THEME_ASSETS.'/vendor/swiper/swiper-bundle.min.css',array(),'1.0','all');
    // MDB CSS File
    wp_enqueue_style('vivaio_theme_stylesheet_mdb5_1',VIVAIO_THEME_MDB5.'/css/mdb.min.css',array(),'1.0','all');
    // Template Stylesheet
    wp_enqueue_style('vivaio_theme_stylesheet_template_1',VIVAIO_THEME_URI.'/style.css',array(),'1.1','all');
    wp_enqueue_style('vivaio_theme_stylesheet_template_2',VIVAIO_THEME_CSS.'/logo.css',array(),'1.0','all');
    wp_enqueue_style('vivaio_theme_stylesheet_template_3',VIVAIO_THEME_CSS.'/menu.css',array(),'1.0','all');
    // Font Awesome
    wp_enqueue_style('vivaio_theme_stylesheet_font_awesome_1','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',array(),'1.0','all');
    // Bootstrap
    wp_enqueue_style('vivaio_theme_stylesheet_bootstrap_1','https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css',array(),'1.0','all');
    // Bootstrap Icons
    wp_enqueue_style('vivaio_theme_stylesheet_bootstrap_icons_1','https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css',array(),'1.0','all');
    // New Template ...
    /* Add your Templates in here ...

    */
}
add_action('wp_enqueue_scripts','dedicate_wp_enqueue');

// Dedicate JavaScript by wp_enqueue_script()
function dedicate_wp_script() {
    // Main JS File
    wp_enqueue_script('vivaio_theme_js_main',VIVAIO_THEME_ASSETS.'/js/main.js',array(),'1.0',true);
    // Vendor JS Files
    wp_enqueue_script('vivaio_theme_js_1',VIVAIO_THEME_ASSETS.'/vendor/bootstrap/js/bootstrap.bundle.min.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_2',VIVAIO_THEME_ASSETS.'/vendor/php-email-form/validate.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_3',VIVAIO_THEME_ASSETS.'/vendor/aos/aos.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_4',VIVAIO_THEME_ASSETS.'/vendor/glightbox/js/glightbox.min.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_5',VIVAIO_THEME_ASSETS.'/vendor/swiper/swiper-bundle.min.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_6',VIVAIO_THEME_ASSETS.'/vendor/imagesloaded/imagesloaded.pkgd.min.js',array(),'1.0',true);
    wp_enqueue_script('vivaio_theme_js_7',VIVAIO_THEME_ASSETS.'/vendor/isotope-layout/isotope.pkgd.min.js',array(),'1.0',true);
    // MDB JS File
    wp_enqueue_script('vivaio_theme_js_8',VIVAIO_THEME_MDB5.'/js/mdb.umd.min.js',array(),'1.0',true);
    // Custom JS File
    wp_enqueue_script('vivaio_theme_custom_js_1',VIVAIO_THEME_JS.'/hieu.js',array(),'1.0',true);
}
add_action('wp_enqueue_scripts','dedicate_wp_script');

/* ----------- Create function that manage all function added into Theme ----------- */
function vivaio_theme_option() {
    // Add Logo
    add_theme_support( 'custom-logo', array(
		'height'      => 200,
		'width'       => 300,
		'flex-width' => true,
	) );
    // Add Thumbnails function
    add_theme_support( 'post-thumbnails' );
    // Add Title Tag
    add_theme_support( 'title-tag' );
    // Register Menu
    register_nav_menus( array (
        'primary_menu' => __( 'Primary Menu', 'vivaio' ),
        'footer_menu'  => __( 'Footer Menu', 'vivaio' ),
    ) );
    // Register Sidebar
    $sidebar = array(
        'name'=> __('Main Sidebar','vivaio'),
        'id'=> 'main-sidebar',
        'description' => 'This is the Main Sidebar of VIVAIO Theme',
        'class' => 'main-sidebar',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>'
    );
    register_sidebar($sidebar);
    // Dedicate LANG folder to translate language
    load_theme_textdomain('vivaio', VIVAIO_THEME_LANG);
    // Change optional background color
    $default_background = array(
        'default-color' => '#c6c6c6',
        'default-repeat' => 'no-repeat',
    );
    add_theme_support('custom-background',$default_background);
    // Add Type of Post Format
    add_theme_support('post-formats',array('aside','gallery','image','video','quote','link'));
}
add_action('init','vivaio_theme_option');

// Create Function that support WooCommerce
function vivaio_woocommerce_setup() {
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'vivaio_woocommerce_setup' );
/* ----------- End of create function that manage all function added into Theme ----------- */

/* ----------- Create function that manage Menu location ----------- */
// Create Menu Register Function ( Primary Menu and Footer Menu )
if ( ! function_exists( 'mytheme_register_nav_menu' ) ) {

	function mytheme_register_nav_menu(){
		register_nav_menus( array(
	    	'primary_menu' => __( 'Primary Menu', 'vivaio' ),
	    	'footer_menu'  => __( 'Footer Menu', 'vivaio' ),
		) );
	}
	add_action( 'after_setup_theme', 'mytheme_register_nav_menu', 0 );
}

// Create Primary Menu
function vivaio_primary_menu(){
    $menu_args = array(
        'theme_location' => 'primary_menu',
        'container' => 'nav',
        'container_class' => 'navmenu',
        'container_id' => 'navmenu',
        'menu' => '',
        'menu_class' => '',
        'menu_id' => '',
        'fallback_cb' => '',
    );
    wp_nav_menu($menu_args);
} 

// Create Footer Menu
function vivaio_footer_menu(){
    $menu_args = array(
        'theme_location' => 'footer_menu',
        'container' => 'div',
        'menu_class' => 'menu',
    );
    wp_nav_menu($menu_args);
    ?>
    <?php
}

/* ----------- End of create function that manage Menu location ----------- */

/* ----------- Create a Solutions Category - different with Posts and Pages ----------- */
/* if ( ! function_exists('vivaio_option') ){
    function vivaio_option($option = '', $default = null){
        $option = get_option('vivaio_cs_option'); // Set ID is primary
        return ( isset($option[$option])) ? $option[ $option ] : $default;
    }
}
class Vivaio_Solutions{
    // Build Construct Function
    // @return__void
    function __construct(){
        add_action('init',array(__CLASS__,'vivaio_Solutions_init'));
        add_filter('single_template',array($this,'portfolio_single'));
    }
public static function vivaio_Solutions_init(){
    if(function_exists('vivaio_option')){
        $slug_text = vivaio_option('Solutions_slug');
    }
    $slug = !empty($slug_text) ? $slug_text: 'solutions'; //https://domain.com/solutions/post/
    register_post_type('solutions',array(
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => $slug ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'show_in_rest'       => true, //REST API
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-admin-network',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'comments', 'elementor' ),
        'labels'             => array(
            'name'               => _x( 'Solutions', 'vivaio' ),
            'singular_name'      => _x( 'Solutions', 'vivaio' ),
            'menu_name'          => _x( 'Solutions', 'vivaio' ),
            'name_admin_bar'     => _x( 'Solutions', 'vivaio' ),
            'add_new'            => _x( 'Add New', 'vivaio' ),
            'add_new_item'       => __( 'Add New Solutions', 'vivaio' ),
            'new_item'           => __( 'New Solutions', 'vivaio' ),
            'edit_item'          => __( 'Edit', 'vivaio' ),
            'view_item'          => __( 'View', 'vivaio' ),
            'all_items'          => __( 'All', 'vivaio' ),
            'search_items'       => __( 'Search', 'vivaio' ),
            'parent_item_colon'  => __( 'Related Solutions:', 'vivaio' ),
            'not_found'          => __( 'Not Found Solutions', 'vivaio' ),
            'not_found_in_trash' => __( 'Not Found Solutions in Trash', 'vivaio' )
            ),
    ));
// Register Solutions Category 
register_taxonomy('solutions_cat',array('solutions'),array(
    'hierarchical' => true,
    'show_ui'      => true,
    'show_in_rest' => true, //REST API
    'show_admin_column' => true,
    'query_var'         => true,
    'rewrite'           => array( 'slug' => trailingslashit('solutions_cat') ),
    'labels'            => array(
        'name'              => _x( 'Category', 'vivaio' ),
        'singular_name'     => _x( 'Category', 'vivaio' ),
        'search_items'      => __( 'Search Category', 'vivaio' ),
        'all_items'         => __( 'All', 'vivaio' ),
        'parent_item'       => __( 'Related Category', 'vivaio' ),
        'parent_item_colon' => __( 'Related Category:', 'vivaio' ),
        'edit_item'         => __( 'Edit', 'vivaio' ),
        'update_item'       => __( 'Update', 'vivaio' ),
        'add_new_item'      => __( 'Add New', 'vivaio' ),
        'new_item_name'     => __( 'Category', 'vivaio' ),
        'menu_name'         => __( 'Category', 'vivaio' ),
            ),
        ) );
//Register Solutions Tag
register_taxonomy( 'solutions_tag', 'solutions', array(
    'hierarchical'          => true,
    'show_ui'               => true,
    'show_admin_column'     => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var'             => true,
    'rewrite'               => array( 'slug' => 'vivaio_Solutions_tag' ),
    'labels'                => array(
        'name'                       => _x( 'Tags', 'vivaio' ),
        'singular_name'              => _x( 'Tag', 'vivaio' ),
        'search_items'               => __( 'Search Tags', 'vivaio' ),
        'popular_items'              => __( 'Popular Tags', 'vivaio' ),
        'all_items'                  => __( 'All', 'vivaio' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Tag', 'vivaio' ),
        'update_item'                => __( 'Update Tag', 'vivaio' ),
        'add_new_item'               => __( 'Add New Tag', 'vivaio' ),
        'new_item_name'              => __( 'New Tag Name', 'vivaio' ),
        'separate_items_with_commas' => __( 'Separate tag with commas', 'vivaio' ),
        'add_or_remove_items'        => __( 'Add or Remove Tag', 'vivaio' ),
        'choose_from_most_used'      => __( 'Choose from most used Tag', 'vivaio' ),
        'not_found'                  => __( 'Not found Tag', 'vivaio' ),
        'menu_name'                  => __( 'Tags', 'vivaio' ),
            ),
    )
    );
}
function portfolio_single($template){
    global $post;
    if($post->post_type == 'vivaio_Solutions'){
        $template = VIVAIO_THEME_DIR.'solutions/single.php';
    }
    return $template;
}
public static function related() {

    global $post;
    // Get the good menu tags.
    $cats = get_the_terms( $post, 'vivaio_Solutions_cat' );

    if ( $cats ) {
        $cat_ids = array();

        foreach ( $cats as $cat ) {
            $cat_ids[] = $cat->term_id;
        }

        $post_perpage = vivaio_option( 'relpost_count' ) ? vivaio_option( 'relpost_count' ) : (int) '3';

        $args = array(
            'post_type'      => 'vivaio_Solutions',
            'post__not_in'   => array( $post->ID ),
            'posts_per_page' => 3,
            'tax_query'      => array(
                array(
                    'taxonomy' => 'vivaio_Solutions_cat',
                    'field'    => 'id',
                    'terms'    => $cat_ids,
                ),
            )
        );

        $the_query = new WP_Query( $args );

        ?>

    <?php }
    wp_reset_postdata();
}
}
$portfolio = new Vivaio_Solutions; */
/* ----------- End of create a Solutions Category - different with Posts and Pages ----------- */

/* ----------- Function to Get title of the Page/ Blog/ Static Page/ Single Post/ ... ----------- */
function get_current_page_title() {
    if (is_front_page()) {
        // Get the title of the front page
        return get_the_title(get_option('page_on_front'));
    } elseif (is_home()) {
        // Get the title of the blog home page
        return get_the_title(get_option('page_for_posts'));
    } elseif (is_page() || is_single()) {
        // Get the title of a static page or single post
        global $post;
        return get_the_title($post->ID);
    } elseif (is_product_category()) {
        return single_term_title();
    } elseif (is_product()) {
        // Display the product name
        return the_title();
    } else {
        // For other cases, return the default title
        return wp_title('', false);
    }
}

/* -------------------------------------------  WooCommerce ------------------------------------------- */

/* --------------------------------- Function to add content of Page Title  --------------------------------- */
function breadcum_and_page_title() {
?>
    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(<?php echo VIVAIO_THEME_ASSETS; ?>/img/about-page-title-bg.jpg);">
      <div class="container">
        <h1><?php echo (get_current_page_title()); ?></h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current"><?php echo (get_current_page_title()); ?></li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->
<?php
}
add_action('woocommerce_before_main_content','breadcum_and_page_title');

/* --------------------------------- Function to change number of related products output  --------------------------------- */
/**
 * Change number of related products output
 */ 
function woo_related_products_limit() {
    global $product;
      
      $args['posts_per_page'] = 6;
      return $args;
  }
  add_filter( 'woocommerce_output_related_products_args', 'jk_related_products_args', 20 );
    function jk_related_products_args( $args ) {
      $args['posts_per_page'] = 3; // 3 related products
      $args['columns'] = 3; // arranged in 3 columns
      return $args;
  }

/* --------------------------------- Function to call Sidebar of WooCommerce  --------------------------------- */

function sidebar_shop(){
    // Check if the current page is the shop page
    if (is_shop()) {
        // No specific category on the shop page, so handle it generally
        $id_current_cat = 0;
        $parent_id = 0;
    } elseif (is_tax('product_cat')) {
        // If on a product category archive page
        $current_category = get_queried_object();
        $id_current_cat = $current_category->term_id;
        $parent_id = $current_category->parent;
    } else {
        return; // Not a relevant page, so exit the function
    }

    // Get child categories if any
    $child_cat = get_terms([
        'taxonomy' => 'product_cat',
        'parent' => $id_current_cat,
        'hide_empty' => false,
    ]);

    // Get sibling categories
    $friend_cat = get_terms([
        'taxonomy' => 'product_cat',
        'parent' => $parent_id,
        'hide_empty' => false,
        'exclude' => $id_current_cat,
    ]);
    ?>

    <div id="service-details" class="col-lg-3 col-12 service-details">
        <div class="container">
            <div class="list-menu row gy-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="service-box">
                        <h4><a href="javascript:;" class="active">
                            <span>
                                <?php 
                                    if (is_shop()) {
                                        echo "Products";
                                    } else {
                                        echo esc_html($current_category->name); 
                                    }
                                ?>
                            </span>
                        </a></h4>

                        <?php if (is_shop()) { ?>
                            <div class="hieu_cate services-list">
                                <div class="hieu_cat">
                                    <ul class="hieu-cat-ul">
                                        <?php
                                        if (!empty($friend_cat)) :
                                            foreach ($friend_cat as $friend) :
                                                $friend_id = $friend->term_id;
                                                $friend_name = $friend->name;
                                                $friend_link = get_term_link($friend);
                                                $active_class = ($friend_id == $id_current_cat) ? 'active' : '';

                                                // Get sub-categories of sibling categories
                                                $friend_sub_cats = get_terms([
                                                    'taxonomy' => 'product_cat',
                                                    'parent' => $friend_id,
                                                    'hide_empty' => false,
                                                ]);
                                                ?>
                                                <li class="<?php echo esc_attr($active_class); ?> hieu-li1 hieu-toggle">
                                                    <h4 class="hieu-toggles"><a href="<?php echo esc_url($friend_link); ?>" class=""><span><?php echo esc_html($friend_name); ?></span></a><i class="fa-solid fa-chevron-down hieu-click"></i></h4>
                                                    <?php if (!empty($friend_sub_cats)) : ?>
                                                        <ul class="sub-hieu">
                                                            <?php foreach ($friend_sub_cats as $sub_cat) : ?>
                                                                <li><a href="<?php echo get_term_link($sub_cat); ?>"><span><?php echo esc_html($sub_cat->name); ?></span></a></li>
                                                            <?php endforeach; ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                </li>
                                            <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } else { ?>
                            <div class="services-list hieu_cate">
                                <ul class="hieu1">
                                    <?php
                                    if (!empty($child_cat)) :
                                        foreach ($child_cat as $cat) :
                                            $cat_id = $cat->term_id;
                                            $cat_name = $cat->name;
                                            $cat_link = get_term_link($cat);
                                            $active_class = ($cat_id == $id_current_cat) ? 'active' : '';

                                            // Get first-level sub-categories
                                            $sub_cats = get_terms([
                                                'taxonomy' => 'product_cat',
                                                'parent' => $cat_id,
                                                'hide_empty' => false,
                                            ]);
                                            ?>
                                            <li class="<?php echo esc_attr($active_class); ?> hieu-li1">
                                                <a href="<?php echo esc_url($cat_link); ?>"><i class=""></i><span><?php echo esc_html($cat_name); ?></span></a>
                                                <?php if (!empty($sub_cats)) : ?>
                                                    <ul class="hieu-sub-sub">
                                                        <?php foreach ($sub_cats as $sub_cat) : ?>
                                                            <li><a href="<?php echo get_term_link($sub_cat); ?>"><span><?php echo esc_html($sub_cat->name); ?></span></a></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php
                                        endforeach;
                                    endif;
                                    ?>
                                </ul>

                                <div class="hieu_cat">
                                    <ul class="hieu-cat-ul">
                                        <?php
                                        if (!empty($friend_cat)) :
                                            foreach ($friend_cat as $friend) :
                                                $friend_id = $friend->term_id;
                                                $friend_name = $friend->name;
                                                $friend_link = get_term_link($friend);
                                                $active_class = ($friend_id == $id_current_cat) ? 'active' : '';

                                                // Get sub-categories of sibling categories
                                                $friend_sub_cats = get_terms([
                                                    'taxonomy' => 'product_cat',
                                                    'parent' => $friend_id,
                                                    'hide_empty' => false,
                                                ]);
                                                ?>
                                                <li class="<?php echo esc_attr($active_class); ?> hieu-li1 hieu-toggle">
                                                    <h4 class="hieu-toggles"><a href="<?php echo esc_url($friend_link); ?>" class=""><?php echo esc_html($friend_name); ?></span></a><i class="fa-solid fa-chevron-down hieu-click"></i><span></h4>
                                                    <?php if (!empty($friend_sub_cats)) : ?>
                                                        <ul class="sub-hieu">
                                                            <?php foreach ($friend_sub_cats as $sub_cat) : ?>
                                                                <li><a href="<?php echo get_term_link($sub_cat); ?>"><span><?php echo esc_html($sub_cat->name); ?></span></a></li>
                                                            <?php endforeach; ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                </li>
                                            <?php
                                            endforeach;
                                        endif;
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
}

add_action('woocommerce_sidebar','sidebar_shop');

/* --------------------------------- Function to create button next to button Read more of WooCommerce  --------------------------------- */
// Firstly, ddd custom field to product general settings
function product_data_sheet_custom_field() {
    global $woocommerce, $post;
    echo '<div class="options_group">';
    woocommerce_wp_text_input(
        array(
            'id'          => '_product_data_sheet',
            'label'       => __('Product Data Sheet URL', 'woocommerce'),
            'placeholder' => 'http://',
            'desc_tip'    => 'true',
            'description' => __('Enter the URL of the product data sheet.', 'woocommerce')
        )
    );
    echo '</div>';
}
add_action('woocommerce_product_options_general_product_data', 'product_data_sheet_custom_field');

// Save custom field data
function save_product_data_sheet_custom_field($post_id) {
    $product_data_sheet = $_POST['_product_data_sheet'];
    if (!empty($product_data_sheet)) {
        update_post_meta($post_id, '_product_data_sheet', esc_url($product_data_sheet));
    }
}
add_action('woocommerce_process_product_meta', 'save_product_data_sheet_custom_field');



/* --------------------------------- Function to remove the Default Product Title of WooCommerce  --------------------------------- */

// Remove the page title on Product Pages and Wocommerce notice wrapper
add_filter('woocommerce_show_page_title','__return_false');

// Remove WooCommerce result count, sorting dropdown, breadcrumb and notice
remove_action('woocommerce_before_single_product', 'woocommerce_output_all_notices', 10);
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );

?>