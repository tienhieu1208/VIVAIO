<?php get_header(); ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(<?php echo VIVAIO_THEME_ASSETS; ?>/img/services-page-title-bg.jpg);">
      <div class="container">
        <h1>Supports</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Supports</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Service Details Section -->
    <section id="service-details" class="service-details section">

      <div class="container">

        <div class="row gy-5">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">

            <div class="service-box">
              <h4>Solutions List</h4>
              <div class="services-list">
                <a href="<?php echo home_url(); ?>/product-category/control-cable-solutions/"><i class="bi bi-arrow-right-circle"></i><span>Control Cable Solutions</span></a>
                <a href="<?php echo home_url(); ?>/product-category/elv-box-solutions/"><i class="bi bi-arrow-right-circle"></i><span>ELV Box Solutions</span></a>
                <a href="<?php echo home_url(); ?>/product-category/fiber-optic-solutions/"><i class="bi bi-arrow-right-circle"></i><span>Fiber Optic Solutions</span></a>
                <a href="<?php echo home_url(); ?>/product-category/lan-cable-solutions/"><i class="bi bi-arrow-right-circle"></i><span>Lan Cable Solutions</span></a>
                <a href="<?php echo home_url(); ?>/product-category/micro-data-center-solutions"><i class="bi bi-arrow-right-circle"></i><span>Micro Data Center Solutions</span></a>
                <a href="<?php echo home_url(); ?>/product-category/rack-cabinet-solutions"><i class="bi bi-arrow-right-circle"></i><span>Rack-Cabinet Solutions</span></a>
              </div>
            </div><!-- End Services List -->

            <div class="service-box">
              <h4>Download Catalog</h4>
              <div class="download-catalog">
                <a target="_blank" href="http://www.localhost/vivaio_wordpress/wp-content/uploads/2024/09/VIVAIO-CATALOGUE-2024.pdf"><i class="bi bi-filetype-pdf"></i><span>Catalog PDF</span></a>
              </div>
            </div><!-- End Services List -->

            <div class="help-box d-flex flex-column justify-content-center align-items-center">
              <i class="bi bi-headset help-icon"></i>
              <h4>Have a Question?</h4>
              <p class="d-flex align-items-center mt-1 mb-0"><i class="bi bi-envelope me-2"></i> <a href="mailto:info@vivaio-electric.com.com">info@vivaio-electric.com</a></p>
            </div>

          </div>

          <div class="col-lg-8 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
            <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/services.jpg" alt="" class="img-fluid services-img">
            <h3>Comprehensive Support for Your Green Spaces</h3>
            <p>
            At VIVAIO, we are dedicated to providing unparalleled support to help you maintain and enhance your landscapes. Our expert team is ready to assist you with everything from plant care to advanced garden management solutions, ensuring your outdoor spaces thrive year-round.
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> <span>Expert guidance on sustainable landscaping practices.</span></li>
              <li><i class="bi bi-check-circle"></i> <span>Tailored advice on plant and soil nutrition for optimal growth.</span></li>
              <li><i class="bi bi-check-circle"></i> <span>Support with the implementation of efficient water management systems.</span></li>
            </ul>
            <p>
            We understand that every landscape is unique, which is why our support services are customized to meet the specific needs of your environment. Whether you're dealing with seasonal challenges or long-term projects, VIVAIO is here to provide the expertise you need.
            </p>
            </p>
            <p>
            Our commitment to your success goes beyond just supplying products; we aim to be your trusted partner in creating and maintaining vibrant, healthy green spaces. Reach out to us for any assistance, and let us help you achieve the best results for your garden or landscape.
            </p>
          </div>

        </div>

      </div>

    </section><!-- /Service Details Section -->

  </main>

<?php get_footer(); ?>