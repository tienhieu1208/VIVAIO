<?php
defined('ABSPATH') || exit;

global $product;
?>
<div class="col-lg-4 col-md-6 mb-4">
    <div class="card">
        <?php if ($product->is_on_sale()) : ?>
            <span class="badge badge-danger">Sale</span>
        <?php endif; ?>

        <div class="view overlay">
            <a href="<?php echo get_permalink(); ?>">
                <?php echo $product->get_image('woocommerce_single', array('class' => 'card-img-top')); ?>
            </a>
        </div>

        <div class="card-body text-center">
            <h5 class="card-title mb-2">
                <a href="<?php echo get_permalink(); ?>" class="text-reset">
                    <?php echo $product->get_name(); ?>
                </a>
            </h5>

            <h6 class="mb-3">
                <strong>
                    <?php echo $product->get_price_html(); ?>
                </strong>
            </h6>
            <div class="card-footer d-flex align-items-end pt-3 px-0 pb-0 mt-auto" data-aos="fade-up">
                <!-- Container for buttons -->
                <div class="d-flex justify-content-between w-100">
                    <!-- Read More Button -->
                    <a href="<?php echo get_permalink(); ?>" class="btn btn-primary">Read more</a>

                    <!-- Product Data Sheet Button -->
                    <a target="_blank" href="<?php echo esc_attr( get_field('product_data_sheet') ); ?>" class="">
                        <i class="bi bi-filetype-pdf"></i><span> Product Data Sheet</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>