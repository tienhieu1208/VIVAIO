<?php get_header(); ?>
  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(<?php echo VIVAIO_THEME_ASSETS; ?>/img/services-page-title-bg.jpg);">
      <div class="container">
        <h1>Solutions</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Solutions</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Services Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Our Solutions</h2>
        <p>Explore our diverse range of horticultural products designed to meet your unique landscaping needs.</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <!-- Service Item 1 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="bi bi-tree" style="color: #f57813;"></i></div>
            <div>
              <h4 class="title">Sustainable Plant Solutions</h4>
              <p class="description">Our wide selection of plants and trees are cultivated with sustainability in mind, ensuring healthy growth and eco-friendliness for every landscape.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div>
          <!-- End Service Item 1 -->

          <!-- Service Item 2 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="bi bi-tools" style="color: #15a04a;"></i></div>
            <div>
              <h4 class="title">Innovative Garden Tools</h4>
              <p class="description">Discover our range of cutting-edge garden tools, designed to simplify maintenance and enhance the beauty of your green spaces.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 2 -->

          <!-- Service Item 3 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="icon flex-shrink-0"><i class="bi bi-droplet" style="color: #d90769;"></i></div>
            <div>
              <h4 class="title">Water Management Systems</h4>
              <p class="description">Efficient irrigation solutions that conserve water and ensure optimal hydration for your plants and landscapes.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 3 -->

          <!-- Service Item 4 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="icon flex-shrink-0"><i class="bi bi-flower3" style="color: #15bfbc;"></i></div>
            <div>
              <h4 class="title">Premium Soil and Fertilizers</h4>
              <p class="description">High-quality soils and fertilizers that provide the essential nutrients your plants need for robust growth and vibrant blooms.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 4-->

          <!-- Service Item 5 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="500">
            <div class="icon flex-shrink-0"><i class="bi bi-globe" style="color: #f5cf13;"></i></div>
            <div>
              <h4 class="title">Global Reach and Support</h4>
              <p class="description">Our products and services are available worldwide, backed by comprehensive customer support to assist you at every step.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 5 -->

          <!-- Service Item 6 -->
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="600">
            <div class="icon flex-shrink-0"><i class="bi bi-people" style="color: #1335f5;"></i></div>
            <div>
              <h4 class="title">Consultation and Design Services</h4>
              <p class="description">Leverage our expertise with personalized consultations and landscape design services tailored to your specific needs and vision.</p>
              <a href="<?php echo home_url();?>/solutions/" class="readmore stretched-link"><span>Learn More</span><i class="bi bi-arrow-right"></i></a>
            </div>
          </div><!-- End Service Item 6 -->

        </div>

      </div>

    </section><!-- /Services Section -->

    <!-- Service Cards Section -->
    <section id="service-cards" class="service-cards section">

      <div class="container-fluid">

        <div class="row gy-4">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cards-1.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Tailored Solutions for Your Business</h4>
                    <p>We provide customized solutions that cater to your specific business needs, ensuring that every service is aligned with your goals and objectives. Our expert team works closely with you to deliver results that exceed expectations.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cards-5.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Innovative Strategies for Growth</h4>
                    <p>Our innovative strategies are designed to drive growth and sustainability for your business. We focus on long-term success by implementing cutting-edge solutions that keep you ahead of the competition.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cards-3.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Expert Consultation Services</h4>
                    <p>Our team of experts offers consultation services that provide you with the insights and guidance needed to make informed decisions. We help you navigate challenges and capitalize on opportunities with confidence.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cards-4.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Comprehensive Support & Maintenance</h4>
                    <p>We offer comprehensive support and maintenance services to ensure that your systems run smoothly and efficiently. Our team is available to assist with any issues, providing peace of mind and continuous operational efficiency.</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>

    </section><!-- /Service Cards Section -->

  </main>
<?php get_footer(); ?>
