<?php get_header(); ?>
  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(<?php echo VIVAIO_THEME_ASSETS; ?>/img/about-page-title-bg.jpg);">
      <div class="container">
        <h1>About Us</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">About Us</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-5">
            <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/about.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-7" data-aos="fade-up" data-aos-delay="200">
            <div class="content">
              <h3>Our Commitment to Excellence</h3>
              <p>
              At VIVAIO, we are dedicated to providing top-notch solutions that enhance your business operations.
              Our team works tirelessly to ensure that every product and service we offer meets the highest standards of quality and innovation.
              With a customer-centric approach, we strive to exceed expectations in every project we undertake.
              </p>
              <ul>
                <li><i class="bi bi-check-circle-fill"></i> <span>Delivering tailored solutions to meet your unique business needs.</span></li>
                <li><i class="bi bi-check-circle-fill"></i> <span>Focused on innovation to help you stay ahead of the competition.</span></li>
                <li><i class="bi bi-check-circle-fill"></i> <span>Committed to exceptional customer support and service.</span></li>
              </ul>
            </div>
          </div>
        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Why Us Section -->
    <section id="why-us" class="why-us section">

      <div class="container">

        <div class="row g-0">

          <div class="col-xl-5 img-bg" data-aos="fade-up" data-aos-delay="100">
            <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/why-us-bg.jpg" alt="">
          </div>

          <div class="col-xl-7 slides position-relative" data-aos="fade-up" data-aos-delay="200">

            <div class="swiper init-swiper">

              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Enhance Your Green Spaces with VIVAIO</h3>
                    <h4 class="mb-3">Dedicated to delivering exceptional quality and sustainable solutions.</h4>
                    <p>At VIVAIO, we believe in enhancing your outdoor environments with top-tier horticultural products. Our commitment to sustainability and quality ensures that every plant, tool, and accessory we offer helps you create vibrant and eco-friendly spaces.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Tailored Solutions for Every Landscape</h3>
                    <h4 class="mb-3">Customized products designed to meet your unique needs.</h4>
                    <p>From bespoke garden designs to robust landscaping tools, VIVAIO provides everything you need to bring your vision to life. Our products are crafted to suit various climatic conditions, ensuring longevity and thriving greenery.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Pioneering Innovation in Horticulture</h3>
                    <h4 class="mb-3">Stay ahead with our cutting-edge gardening technology.</h4>
                    <p>Embrace the future of gardening with VIVAIO's innovative solutions. Our advanced tools and technologies are designed to simplify your gardening efforts while maximizing growth and sustainability.</p>
                  </div>
                </div><!-- End slide item -->

                <div class="swiper-slide">
                  <div class="item">
                    <h3 class="mb-3">Committed to Customer Satisfaction</h3>
                    <h4 class="mb-3">Your gardening success is our top priority.</h4>
                    <p>At VIVAIO, we go beyond just selling products—we provide a partnership. Our expert team is dedicated to supporting you at every step of your gardening journey, ensuring a fruitful and enjoyable experience.</p>
                  </div>
                </div><!-- End slide item -->

              </div>
              <div class="swiper-pagination"></div>
            </div>

            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
          </div>

        </div>

      </div>

    </section><!-- /Why Us Section -->

    <!-- Call To Action Section -->
    <section id="call-to-action" class="call-to-action section dark-background">

      <img src="<?php echo VIVAIO_THEME_ASSETS; ?>/img/cta-bg.jpg" alt="">

      <div class="container">
        <div class="row justify-content-center" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-xl-10">
            <div class="text-center">
              <h3>Ready to Elevate Your Business?</h3>
              <p>Join us in transforming your business with innovative solutions and dedicated support. Together, we can drive success and growth, tailored specifically to your needs.</p>
              <a class="cta-btn" href="<?php echo home_url();?>/contact/">Get Started Now</a>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Call To Action Section -->

  </main>

  
  <?php get_footer(); ?>
  <script>  var swiper = new Swiper(".swiper.init-swiper", {
    cssMode: true,
    loop: true,
    speed: 800,
    autoplay:{
      delay: 5000,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
      clickable: true
    },
    mousewheel: true,
    keyboard: true,
    breakpoints: {
      768: {
        slidesPerView: 1,
        spaceBetween: 40
            },
      1200: {
        slidesPerView: 1,
        spaceBetween: 1
            }
      }
  });
  </script>
