<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title><?php get_current_page_title(); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php
    $favicon_url = get_site_icon_url();
    if ($favicon_url) {
        echo '<link rel="icon" href="' . esc_url($favicon_url) . '" sizes="32x32" />';
        echo '<link rel="icon" href="' . esc_url($favicon_url) . '" sizes="192x192" />';
        echo '<link rel="apple-touch-icon" href="' . esc_url($favicon_url) . '" />';
        echo '<meta name="msapplication-TileImage" content="' . esc_url($favicon_url) . '" />';
    } else {
        // Fallback if no site icon is set
        echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url(VIVAIO_THEME_FAVICON . '/apple-touch-icon.png') . '" />';
        echo '<link rel="icon" type="favicon/png" size="32x32" href="' . esc_url(VIVAIO_THEME_FAVICON . '/favicon-32x32.png') . '" />';
        echo '<link rel="icon" type="favicon/png" size="16x16" href="' . esc_url(VIVAIO_THEME_FAVICON . '/favicon-16x16.png') . '" />';
        echo '<link rel="manifest" href="' . esc_url(VIVAIO_THEME_FAVICON . '/site.webmanifest') . '" />';
    }
  ?>
<?php wp_head(); ?>
</head>

<body class="index-page">
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
        <?php
        if ( function_exists( 'the_custom_logo' ) ) {
	        the_custom_logo();
        }
        ?>
      <div class="menu-h">
        <?php vivaio_primary_menu(); ?>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        <?php echo do_shortcode('[gtranslate]'); ?>
        
      </div>
      
    </div>
  </header>
