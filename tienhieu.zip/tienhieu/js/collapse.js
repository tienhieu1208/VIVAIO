document.addEventListener('DOMContentLoaded', function () {
    var accordionElements = document.querySelectorAll('.accordion-button');

    accordionElements.forEach(function (button) {
        button.addEventListener('click', function () {
            var target = button.getAttribute('data-mdb-target');
            var collapseElement = document.querySelector(target);

            if (collapseElement.classList.contains('show')) {
                // Collapse the accordion with smooth effect
                collapseElement.style.height = collapseElement.scrollHeight + 'px'; // Set to current full height
                collapseElement.offsetHeight; // Force reflow to apply height
                collapseElement.style.height = 0; // Animate to zero height
                
                collapseElement.classList.remove('show');
                collapseElement.classList.add('collapsing');

                setTimeout(function () {
                    collapseElement.classList.remove('collapsing');
                    collapseElement.classList.add('collapse');
                    collapseElement.style.height = ''; // Reset inline style
                }, 350); // Match the duration to the transition time
            } else {
                // Expand the accordion with smooth effect
                collapseElement.classList.remove('collapse');
                collapseElement.classList.add('collapsing');
                collapseElement.style.height = 0; // Start from zero height
                
                setTimeout(function () {
                    collapseElement.style.height = collapseElement.scrollHeight + 'px'; // Animate to full height
                }, 10);

                setTimeout(function () {
                    collapseElement.classList.remove('collapsing');
                    collapseElement.classList.add('collapse', 'show');
                    collapseElement.style.height = ''; // Reset inline style after animation
                }, 350); // Match the duration to the transition time
            }
        });
    });
});
