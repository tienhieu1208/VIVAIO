// Select all menu items with the class 'hieu-toggle'
const hieuToggles = document.querySelectorAll('.hieu-toggle');

hieuToggles.forEach(function(hieuToggle) {
    hieuToggle.addEventListener('click', function() {
        // Kiểm tra nếu mục đã có 'active' class
        if (hieuToggle.classList.contains('active')) {
            // Nếu có, xóa lớp 'active'
            hieuToggle.classList.remove('active');

            // Đồng thời xóa lớp 'active' từ các submenu nếu có
            const subHieu = hieuToggle.querySelector('.sub-hieu');
            const hieuSubSub = hieuToggle.querySelector('.hieu-sub-sub');
            if (subHieu) {
                subHieu.classList.remove('active');
            }
            if (hieuSubSub) {
                hieuSubSub.classList.remove('active');
            }
        } else {
            // Nếu không có, xóa lớp 'active' từ tất cả các mục khác
            hieuToggles.forEach(function(item) {
                item.classList.remove('active');
                // Đồng thời xóa lớp 'active' từ các submenu của các mục khác
                const subHieu = item.querySelector('.sub-hieu');
                const hieuSubSub = item.querySelector('.hieu-sub-sub');
                if (subHieu) {
                    subHieu.classList.remove('active');
                }
                if (hieuSubSub) {
                    hieuSubSub.classList.remove('active');
                }
            });

            // Thêm lớp 'active' vào mục menu hiện tại
            hieuToggle.classList.add('active');

            // Thêm lớp 'active' cho các submenu nếu có
            const subHieu = hieuToggle.querySelector('.sub-hieu');
            const hieuSubSub = hieuToggle.querySelector('.hieu-sub-sub');
            if (subHieu) {
                subHieu.classList.add('active');
            }
            if (hieuSubSub) {
                hieuSubSub.classList.add('active');
            }
        }
    });
});
